<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- DataTables -->
<script src="<?php echo e(asset('public/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(function () {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging'      : true,
            'lengthChange': false,
            'searching'   : false,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false
        })
    })
</script>
</head>
<body>

</body>
</html>
<p>My name is <b><?php echo e($data['first_name']); ?> <?php echo e($data['MI']); ?> <?php echo e($data['last_name']); ?></b> </p>
<p>I would like to apply for a <b><?php echo e($data['position_desired']); ?></b> position starting from <b><?php echo e($data['date_available']); ?></b> on a 
<b><?php echo e($data['employment_type']); ?></b> basis.</p>
<h3>Personal Information</h3>
<table>
	<tr>
		<td>Street: <b><?php echo e($data['street_address']); ?></b></td>
		<td>City: <b><?php echo e($data['city']); ?></b></td>
		<td>State: <b><?php echo e($data['state']); ?></b></td>
	</tr>
	<tr>
		<td>Home Phone: <b><?php echo e($data['home_phone']); ?></b></td>
		<td>Alternative Phone: <b><?php echo e($data['alt_phone']); ?></b></td>
		<td>Email: <b><?php echo e($data['your_email']); ?></b></td>
	</tr>
	<tr>
		<td>Do you have a valid drivers license?  <b><?php echo e($data['drivers_license']); ?></b></td>
		<td>Class:  <b><?php echo e($data['class']); ?></b></td>
	</tr>
	<tr>
		<td>Have you ever served in the military? <b> <?php echo e($data['military']); ?></b></td>
	</tr>
	<tr>
		<td>Do you have the legal right to obtain employment in the United States? <b><?php echo e($data['employment_right']); ?></b></td>
	</tr>
	<tr>
		<td>Can you perform the essential functions and responsibilities of the position for which you are applying? <b><?php echo e($data['performance']); ?></b></td>
	</tr>
	<tr>
		<td>Explanation: <b><?php echo e($data['performance_explanation']); ?></b></td>
	</tr>
	<br>
	<tr>
		<td><h3>License/Certifcation</h3></td>
	</tr>
	<tr>
		<td>Do you require any special accommodation to perform required duties? <b><?php echo e($data['special_accommodation']); ?></b></td>
	</tr>
	<tr>
		<td>Explanation: <b><?php echo e($data['accommodation_explanation']); ?></b></td>
	</tr>
	<tr>
		<td>Have you ever worked for Seven Hills Medical Solutions? <?php echo e($data['previous_worker']); ?><b></b></td>
	</tr>
	<tr>
		<td>Position held: <?php echo e($data['position_held']); ?></td>
		<td>Date: <?php echo e($data['employment_date']); ?></td>
	</tr>
	<tr>
		<td>Do any of your relatives work for Seven Hills? <b><?php echo e($data['relative_working']); ?></b></td>
		<td>Name: <b><?php echo e($data['relative_name']); ?></b></td>
	</tr>
	<tr>
		<td>Certifications: <b><?php echo e($data['certifications']); ?></b></td>
	</tr>
	<tr>
		<td>Convicted of criminal offense? <b><?php echo e($data['criminal_offense']); ?></b></td>
	</tr>
	<!-- References -->
	<br>
	<tr>
		<td><h3>References</h3></td>
	</tr>
	<tr>
		<td><h5>Reference 1</h5></td>
	</tr>
	<tr>
		<td><?php echo e($data['reference_name']); ?></td>
		<td><?php echo e($data['reference_phone_number']); ?></td>
		<td><?php echo e($data['reference_mail_address']); ?></td>
	</tr>
	<tr>
		<td><h5>Reference 2</h5></td>
	</tr>
	<tr>
		<td><?php echo e($data['reference_name_2']); ?></td>
		<td><?php echo e($data['reference_phone_number_2']); ?></td>
		<td><?php echo e($data['reference_mail_address_2']); ?></td>
	</tr>
	<tr>
		<td><h5>Reference 3</h5></td>
	</tr>
	<tr>
		<td><?php echo e($data['reference_name_3']); ?></td>
		<td><?php echo e($data['reference_phone_number_3']); ?></td>
		<td><?php echo e($data['reference_mail_address_3']); ?></td>
	</tr>
	<br>
	<!-- Education and skills -->
	<tr>
		<td><h3>Education & Skills</h3></td>
	</tr>
	<tr>
		<td>Education Level: <b><?php echo e($data['education_level']); ?></b></td>
	</tr>
	<tr>
		<td>Degree Major: <b><?php echo e($data['degree_major']); ?></b></td>
	</tr>
	<tr>
		<td>Skills: <b><?php echo e($data['skills']); ?></b></td>
	</tr>
	<!-- Experience 1 -->
	<br>
	<tr>
		<td><h3>Experience</h3></td>
	</tr>
	<tr>
		<td>From: <b><?php echo e($data['from_date']); ?></b></td>
		<td>To: <b><?php echo e($data['to_date']); ?></b></td>
	</tr>
	<tr>
		<td>Start salary: <b><?php echo e($data['start_salary']); ?></b></td>
	</tr>
	<tr>
		<td>Employer name: <b><?php echo e($data['employer_name']); ?></b></td>
	</tr>
	<tr>
		<td>May we contact the previous employer? <b><?php echo e($data['contact_permission']); ?></b></td>
	</tr>
	<tr>
		<td>Street: <b><?php echo e($data['street_address']); ?></b></td>
		<td>City: <b><?php echo e($data['city']); ?></b></td>
		<td>State: <?php echo e($data['state']); ?></td>
	</tr>
	<tr>
		<td>Home Phone: <b><?php echo e($data['home_phone_employer']); ?></b></td>
	</tr>
	<tr>
		<td>Titles & Duties performed: <b><?php echo e($data['title_performed']); ?></b></td>
	</tr>
	<tr>
		<td>Reason for leaving: <b><?php echo e($data['reason_leaving']); ?></b></td>
	</tr>
	<br>
	<!-- Experience 2 -->
	<tr>
		<td><h3>Experience 2</h3></td>
	</tr>
	<tr>
		<td>From: <b><?php echo e($data['from_date_experience2']); ?></b></td>
		<td>To: <b><?php echo e($data['to_date_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Start salary: <b><?php echo e($data['start_salary_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Employer name: <b><?php echo e($data['employer_name_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>May we contact the previous employer? <b><?php echo e($data['contact_permission_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Street: <b><?php echo e($data['street_address_employer_experience2']); ?></b></td>
		<td>City: <b><?php echo e($data['city_employer_experience2']); ?></b></td>
		<td>State : <b><?php echo e($data['state_employer_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Home Phone: <b><?php echo e($data['home_phone_employer_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Titles & Duties performed: <b><?php echo e($data['title_performed_experience2']); ?></b></td>
	</tr>
	<tr>
		<td>Reason for leaving: <b><?php echo e($data['reason_leaving_experience2']); ?></b></td>
	</tr>

</table>



<?php /**PATH /home1/jasbancl/public_html/sevenhillsmed.com/resources/views/email_template.blade.php ENDPATH**/ ?>