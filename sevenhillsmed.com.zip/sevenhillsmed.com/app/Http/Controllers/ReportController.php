<?php
/**
 * Created by PhpStorm.
 * User: jojimdogo
 * Date: 26/08/2019
 * Time: 20:17
 */

namespace App\Http\Controllers;


class ReportController
{
    public function index()
    {
        return view('report');
    }
}