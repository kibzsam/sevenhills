<?php
/**
 * Created by PhpStorm.
 * User: jojimdogo
 * Date: 8/24/2019
 * Time: 9:36 AM
 */

namespace App\Http\Controllers;


class ApplicationFormController
{
    public function index()
    {
        return view('applicationForm');
    }
}